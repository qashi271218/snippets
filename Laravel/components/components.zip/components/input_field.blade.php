<div class="form-group">
@if(isset($name))
<label class="text-capitalize">{{$name}}</label>
@endif
<input type="{{$type}}" class="form-control" name="{{isset($name) ? $name : ''}}" value="{{isset($value) ? $value : ''}}" {{isset($parameter) ? $parameter : ''}}>
</div>