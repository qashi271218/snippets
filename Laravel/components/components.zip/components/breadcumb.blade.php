<li class="nav-item d-none d-sm-inline-block">
<a href="{{url('/')}}" class="nav-link">Home</a>
</li>
<li class="nav-item d-none d-sm-inline-block">
<a href="#" class="nav-link">{{$title1}}</a>
</li>
@if(isset($title2))
<li class="nav-item d-none d-sm-inline-block">
<a href="#" class="nav-link">{{$title2}}</a>
</li>
@endif