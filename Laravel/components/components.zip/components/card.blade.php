<div class="card card-primary">
<div class="card-header">
<h3 class="card-title">{{$title}}</h3>
</div>
<!-- /.card-header -->
<!-- form start -->
<div class="card-body">
{{$slot}}
</div>
</div>