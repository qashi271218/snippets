<div class="form-group">
<label>Description</label>
<textarea class="summernote" name="{{$name}}">{!!$value!!}</textarea>
</div>