<div class="input-group form-group">
<div class="input-group-prepend">
<span class="input-group-text"><i class="{{$icon}}"></i></span>
</div>
<input type="{{$type}}" class="form-control" name="{{$name}}" value="{{$value}}">
</div>