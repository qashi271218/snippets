<div class="form-group">
<label class="text-capitalize">{{$name}}</label>
<div class="input-group">
  <div class="custom-file">
    <input type="{{$type}}" class="custom-file-input" id="exampleInputFile" name="{{$name}}">
    <label class="custom-file-label" for="exampleInputFile">Choose file</label>
  </div>
</div>
@if(isset($src))
<img src="{{asset($src)}}" width="50">
@endif
</div>