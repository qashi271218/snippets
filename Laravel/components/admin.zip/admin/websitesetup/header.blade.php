@extends('admin.layouts.app')
@section('header')
@component('components.breadcumb',['title1'=>'Website Setup','title2'=>'Header'])
 @endcomponent
@endsection
@section('content')
<div class="row container">
<div class="col-md-5 pt-3">
    @component('components.card',['title'=>'Header Setting'])
              <form method="post" action="{{route('admin.website.header.update')}}" enctype= multipart/form-data>
                  {{csrf_field()}}
                  @component('components.input_field_file',['type'=>'file','name'=>'logo','src'=>"public/admin/website_setup/header/$header->logo"])@endcomponent
                  @component('components.input_field_file',['type'=>'file','name'=>'favicon','src'=>"public/admin/website_setup/header/$header->favicon"])@endcomponent
                  @component('components.submit_button',['name'=>'Submit'])
                  @endcomponent
              </form>
    @endcomponent
</div>
<div class="col-md-7 pt-3">
    @component('components.card',['title'=>'Header Nav MenuSetting'])
                    @foreach($menus as $menu)
                    <div class="row gutters-5">
										<div class="col-4">
										    @component('components.input_field',['type'=>'text','value'=>$menu->name,'parameter'=>'readonly'])@endcomponent
										</div>
										<div class="col">
											<div class="form-group">
											@component('components.input_field',['type'=>'text','value'=>$menu->link,'parameter'=>'readonly'])@endcomponent
											</div>
										</div>
										<div class="col-auto">
											<a href="{{route('admin.website.header.nav.delete',[$menu->id])}}" class="delete-confirm"><i class="fas fa-trash text-danger"></i></a>
										</div>
									</div>
                    @endforeach
                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#addNavItem">
Add New</button>
    @endcomponent
</div>
</div>
<!-- Modal -->
@component('components.modal',['id'=>'addNavItem','title'=>'Add Menu'])
<form method="post" action="{{route('admin.website.header.nav.store')}}" autocomplete="off">
            {{csrf_field()}}
            @component('components.input_field',['type'=>'text','name'=>'name'])@endcomponent
            @component('components.input_field',['type'=>'text','name'=>'link'])@endcomponent
                  <button type="submit" class="btn btn-primary">Submit</button>
        </form>
@endcomponent
@endsection