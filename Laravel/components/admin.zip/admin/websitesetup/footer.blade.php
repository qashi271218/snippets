@extends('admin.layouts.app')
@section('header')
     @component('components.breadcumb',['title1'=>'Website Setup','title2'=>'Footer'])
 @endcomponent
@endsection
@section('content')
<div class="row container p-3">
<div class="col-md-6">
    @component('components.card',['title'=>'Footer Setting'])
              <form method="post" action="{{route('admin.website.footer.update')}}" enctype= multipart/form-data>
                  {{csrf_field()}}
                  @component('components.input_field_file',['type'=>'file','name'=>'logo','src'=>"public/admin/website_setup/footer/$footer->logo"])@endcomponent
                  @component('components.input_field',['type'=>'text','name'=>'address','value'=>$footer->address])@endcomponent
                  @component('components.input_field',['type'=>'text','name'=>'phone','value'=>$footer->phone])@endcomponent
                  @component('components.input_field',['type'=>'email','name'=>'email','value'=>$footer->email])@endcomponent
                  @component('components.input_field',['type'=>'text','name'=>'copyright','value'=>$footer->copyright])@endcomponent
                  @component('components.input_field_textarea',['name'=>'description','value'=>$footer->description])@endcomponent
                  @component('components.submit_button',['name'=>'Submit'])
                  @endcomponent
              </form>
@endcomponent
</div>
<div class="col-md-6">
    @component('components.card',['title'=>'Footer Setting'])
              <form method="post" action="{{route('admin.website.footer.social.update')}}">
                  {{csrf_field()}}
                  <div class="form-group">
                        <label>Social Links</label>
                        @component('components.input_field_append',['icon'=>'fab fa-facebook-f','type'=>'text','name'=>'facebook','value'=>$social->facebook])@endcomponent
                        @component('components.input_field_append',['icon'=>'fab fa-twitter','type'=>'text','name'=>'twitter','value'=>$social->twitter])@endcomponent
                        @component('components.input_field_append',['icon'=>'fab fa-instagram','type'=>'text','name'=>'instagram','value'=>$social->instagram])@endcomponent
                        @component('components.input_field_append',['icon'=>'fab fa-youtube','type'=>'text','name'=>'youtube','value'=>$social->youtube])@endcomponent
                        @component('components.input_field_append',['icon'=>'fab fa-linkedin-in','type'=>'text','name'=>'linkedin','value'=>$social->linkedin])@endcomponent
                    </div>
                  @component('components.submit_button',['name'=>'Submit'])
                  @endcomponent
              </form>
@endcomponent
</div>
</div>
@endsection