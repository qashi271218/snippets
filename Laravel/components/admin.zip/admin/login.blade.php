@extends('frontend.layouts.app')
@section('content')
    <div class="modal-dialog modal-dialog-centered" role="document">
      <div class="modal-content">
          <h5 class="modal-title text-center" id="exampleModalLabel"><img src="https://hwinfotech.in/staging/auctioncars/public/frontend/img/logo.png" alt=""></h5>
        <form method="post" action="{{route('admin.login')}}" autocomplete="off">
            {{csrf_field()}}
            <div class="form-group">
              <label for="email1">Email address</label>
              <input type="email" class="form-control" name="email" aria-describedby="emailHelp" value="{{old('email')}}" placeholder="Enter email" required>        
            </div>
            <div class="form-group">
              <label for="password1">Password</label>
              <input type="password" class="form-control" name="password" placeholder="Password" required>
              <small id="emailHelp" class="form-text text-right font-size-13px"><a href="#"> Forgotten your password?</a></small>
            </div>
            <div class="space20"></div>
            <button type="submit" class="btn mainBtn2 btn-block">SIGN IN</button>
        </form>
      </div>
    </div>
@endsection